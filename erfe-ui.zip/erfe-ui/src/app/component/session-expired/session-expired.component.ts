import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-session-expired',
  templateUrl: './session-expired.component.html'
})
export class SessionExpiredComponent implements OnInit {
/**�Constructor for SessionExpiredComponent
�*�
�*/
  constructor() {
  }
  /**Calling the ngOnInit() 
  * 
  */
  ngOnInit() {
  }

}
