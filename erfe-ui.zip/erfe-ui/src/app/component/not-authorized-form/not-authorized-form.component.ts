import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-authorized-form',
  templateUrl: './not-authorized-form.component.html',
  styleUrls: ['./not-authorized-form.component.scss']
})
export class NotAuthorizedFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
