import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss']
})
export class AdministrationComponent implements OnInit {

  /**�Constructor for AdministrationComponent
   *�@author senthil
   */

  constructor() { }

  /**�Calling the ngOnInit() method
   *�
   */

  ngOnInit() {
  }

}
