import {Component} from '@angular/core';

@Component({
  selector: 'app-down-maintenance',
  templateUrl: './down-maintenance.component.html'
})
export class DownMaintenanceComponent {
  
  /**�showHeader = false;
�*�
�*/
/**�Constructor for DownMaintenanceComponent
�*�
�*/

  constructor() {
  }


}
