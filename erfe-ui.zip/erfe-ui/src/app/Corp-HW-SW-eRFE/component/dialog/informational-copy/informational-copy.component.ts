import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informational-copy',
  templateUrl: './informational-copy.component.html',
  styleUrls: ['./informational-copy.component.css']
})
export class InformationalCopyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
