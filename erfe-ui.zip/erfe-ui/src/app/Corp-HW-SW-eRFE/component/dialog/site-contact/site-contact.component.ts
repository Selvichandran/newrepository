import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-contact',
  templateUrl: './site-contact.component.html',
  styleUrls: ['./site-contact.component.css']
})
export class SiteContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
