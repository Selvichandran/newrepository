import { Component, OnInit, ViewChild } from '@angular/core';
import { AppConstant } from '../../shared/app.constant';
import * as moment from 'moment';
import { FormArray } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-new-corp-hw-sw-erfe',
  templateUrl: './new-corp-hw-sw-erfe.component.html',
  styleUrls: ['./new-corp-hw-sw-erfe.component.css']
})
export class NewCorpHwSwErfeComponent implements OnInit {
  newRFEDocument: FormGroup;
  // Footer
  currentYear: string = moment(new Date()).format("YYYY");

  // Create a busy object to display in the spinner
  // busyLogin = new Subscription();
  busyLoading = false;
  // have to change
  loadingMessage = AppConstant.LOGIN_MESSAGE;
  todayDate: Date = new Date();

      /** Validation 
      * 
     */
    siteContactNameValid: boolean = false;
    siteContactMsg: string = '';
    orderFromValid: boolean = false;
    orderFromMsg: string = '';
    startDateValid: boolean = false;
    startDateMsg: string = '';
    completionDateValid: boolean = false;
    completionDateMsg: string = '';
    workerRowsToAddValid: boolean = false;
    workerRowsToAddMsg: string = '';
    approvalRowsToAddValid: boolean = false;
    approvalRowsToAddMsg: string = '';
    projectTitleValid: boolean = false;
    projectTitleMsg: string = '';
    descAllServeValid: boolean = false;
    descAllServeMsg: string = '';

    // estKeyPress: boolean = true;
    // rateKeyPress: boolean = true;
    // addexpKeyPress: boolean = true;
    // fixedKeyPress: boolean = true;

    distributionValid: boolean = false;
    distributionPMsg: number;
    distributionMsg: string = '';
    distributionSum: number = 0;
    distributionKeyPress: boolean = true;
    approvalValid: boolean = false;
    approvalMsg: string = '';
    percentValid: boolean = false;
    percentMsg: string = '';
    infoValid: boolean = false;
    infoMsg: string = '';
    fixedBidMsg: string = '';
    fixedBidValid: boolean = false;
    isRetract: boolean = true;
    resourceMsg: string = AppConstant.resourceTitleRequiredMessage;;
    estMsg: string = AppConstant.estHoursRequiredMessage;
    rateMsg: string = AppConstant.rateRequiredMessage;
    selectedApprover: string;
    accountNoMsg: string = AppConstant.accountNoRequiredMessage;
    accountNoValid = false;
    accountNoPMsg: number;
    costCenterMsg: string = AppConstant.costCenterRequiredMessage;
    costCenterValid = false;
    costCenterPMsg: number;
    requiredFullPop: boolean = false;
    approvalAmountZeroMsg: string = '';
    approvalAmountZeroValid: boolean = false;
    savedAsDraftRequiredPopup: boolean = false;
    retractDisplay: boolean = false;
    retractComments: string;
    requestorDetails: string = "";
    requestorData: string;
    isRequestComment: boolean = true;

    // Enhancement
    @ViewChild('siteContactName', { static: false }) siteContactName: any;
    userLastName: string = '';
    userFirstName: string = '';
    userSupplierName: string = '';
    siteContactNameNotAvailable: boolean = false;
    siteContactNameNotAvailableMsg: string = '';
    projectCoordinatorNameNotAvailable: boolean = false;
    projectCoordinatorNameNotAvailableMsg: string = '';
    supplierNameNotAvailable: boolean = false;
    supplierNameNotAvailableMsg: string = '';
    approverNameNotAvailable: boolean = false;
    approverNameNotAvailableMsg: string = '';
    inforNameNotAvailable: boolean = false;
    inforNameNotAvailableMsg: string = '';
    infoMsgIndex: number;
    confirmPrintPopup: boolean = false;

    /** Same Name insertion validation
     * 
    */
    siteContactNameCheck: boolean = false;
    siteContactNameCheckMsg: string = '';
    coordinatorNameCheck: boolean = false;
    coordinatorNameCheckMsg: string = '';
    approvalNameCheck: boolean = false;
    approvalNameCheckMsg: string;
    approvalPMsg: number;
    allNameCheckForSubmit: boolean = false;

    /**  For approver Limit Check	
         * 
        */
    approverId: string;
    individualApproverLimit: number;
    greatestApproverLimit: number;
    approverLimitValid: boolean = false;
    activityLogConstruct: any[];

    /** Renewal Number validation
      * 
      */
    rfeNumberForRenewal: any;
    rfeNumberExist: boolean = false;
    /** For worker info caluculation
        *
        */
    multipliedValue: number = 0;
    approvalAmount: number = 0;
    currentEstValue: number = 0;
    currentRateValue: number = 0;
    currentAdditionalExpensesValue: number = 0;
    currentfixedBidAmountValue: number = 0;

    display: boolean;
    readMode: false;
    readonly = false;
    uploadedFiles: any[] = [];
    attachments: any[] = [];
    renewalAttachments: any[] = [];
    approveComments: string;
    rejectComments: string;
    contactNameList: any[];
    logs: any[];
    cols: any[];
    nameHeaders: any[];
    nameValues: any[];
    coordinatorsHeaders: any[];
    coordinatorsValues: any[];
    orderHeaders: any[];
    orderValues: any[];
    accountHeaders: any[];
    accountValues: any[];
    informationHeaders: any[];
    informationValues: any[];
    approvalHeaders: any[];
    approvalValues: any[];
    deptHeaders: any[];
    deptValues: any[];
    siteNameDisplay: boolean = false;
    ptCoordinaterDisplay: boolean = false;
    orderDisplay: boolean = false;
    accountDisplay: boolean = false;
    informationalDisplay: boolean = false;
    approvalNameDisplay: boolean = false;
    deptDisplay: boolean = false;
    index: number;
    corpReqNum: string;
    noRecordFoundInd = false;
    rfeNumber: string;
    approveDisplay: boolean = false;
    rejectDisplay: boolean = false;
    renewalDisplay: boolean = false;
    userRole: string;
    userId: string;
    user: string;
    isDisable: boolean = false;
    isSave: boolean = true;
    isComments: boolean = false;
    isClosable: boolean = true;
    isSubmit: boolean = true;
    supplierInformationId: number = 0;
    busySave: Subscription;
    alerts = [];
    corpResults: any;
    input: string;
    action: string;
    docId: number;
    isApprover: boolean = false;
    isRenewal: boolean = false;
    isEditable: boolean = false;
    commentsDisplay: boolean = false;
    formData: any;
    approverComments: any;
    pendingApprovers: any;
    pendingApproverAsString: string = '';
    isAdmin: boolean = false;
    formStatus: string;
    navigationSubscription: any;
    paramsSub: any;
    reqNum: string;
    oldCorpReqNum: string;
    renewalData: any;
    isPrintable: boolean = true;
    rfeNoLabel: string = 'RFE No.';
    submitted: boolean;
    busy: Subscription;
    isRenewalForm: boolean;
    minDate: Date;
    maxDate: Date;
    currentApproverIndicator: boolean = false;
    currentApproverIndex: number = -1;
    currentRFEDocumentContentFromPrint: string = '';
    specificErrorMessagesContainer: any[] = [];
    toastSuccess: string;
    toastError: string;
    formCorpReqNumber: string = "0";

    accountNoDataList: any[] = [];
    costCenterDataList: any[] = [];
    validateAccountingTable: { [key: string]: any };
    accountNoInValid = false;
    accountNoInValidPMsg: number;
    costCenterInValid = false;
    costCenterInValidPMsg: number;

    // Admin edit approved form
    isEditSaveApprovedForm: boolean = false;
    adminEditInfoCopyLength: number;
    adminEditUpdateAddRowButtonShow: boolean = false;

    // For Mobile	
    deviceInfo = null;
    isMobile: boolean = false;

    // Not Used
    isVisible: boolean = false;
    @ViewChild('uploader', { static: false }) uploadInput: any;
    isUser: boolean;

    /** Dynamic Table
     * 
     */
    get workerInfo(): FormArray {
        return this.newRFEDocument.get('workerInfo') as FormArray;
    }

    get acctInfo(): FormArray {
        return this.newRFEDocument.get('acctInfo') as FormArray;
    }

    get approval(): FormArray {
        return this.newRFEDocument.get('approval') as FormArray;
    }

    get informationalCopy(): FormArray {
        return this.newRFEDocument.get('informationalCopy') as FormArray;
    }

  constructor() { }

  ngOnInit() {

  }

}
