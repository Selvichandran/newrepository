export class Announcement {
  id: number;
  message = '';
  locationId: number;
  active: boolean;
}
