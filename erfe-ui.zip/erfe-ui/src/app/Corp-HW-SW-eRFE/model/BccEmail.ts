export class BccEmail {
  id: number;
  email = '';
}
