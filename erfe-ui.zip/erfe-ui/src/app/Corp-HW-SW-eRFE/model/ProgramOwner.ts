export class ProgramOwner {
  firstName = '';
  lastName = '';
  locationId: number;
  userPin = '';
  email = '';
}
