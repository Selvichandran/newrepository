export class SignUpUser {
  firstName = '';
  lastName = '';
  userPin = '';
  email = '';
}
