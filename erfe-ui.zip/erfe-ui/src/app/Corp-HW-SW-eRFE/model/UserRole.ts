export class UserRole {
    roleId: number;
    roleNme = '';
}

