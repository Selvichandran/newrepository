export class User {
  firstName = '';
  lastName = '';
  userPin = '';
  email = '';
}

