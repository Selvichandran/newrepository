export class ContactUs {
  id: number;
  message = '';
  locationId: number;
}
