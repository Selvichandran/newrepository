export class IRequestor {
    approverAction: string;
    approverName: string;
    approverPin: string;
    corpPsNumber: string;
    createdDate: Date;
    docId: number;
    id: number;
    requestorName: string;
    rfeNum: string;
    status: string;
    projectTitle:string;
   
}