export class CorpsSearch{
  status:string='';
  contactName:string='';
  rfeNum:number;
  corpPSReqNum:string='';
  supplier:string='';
  projectTitle:string='';
  projectDesc:string='';

  wbs:string='';
  costCenter:string='';
  approvedAmount:number;
  currentApprover:string;
}
