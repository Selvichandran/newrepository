export class ProviderMaster{
    providerId:number=0;
    providerName:string='';
    isActive:boolean=true;

}