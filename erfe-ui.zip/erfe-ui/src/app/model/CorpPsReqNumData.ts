
      //senthil dec-4
export class CorpPsReqNumData{

    id:number;
    personId:string;
    psIdentity:string;

    reqNum:string;

}
      //senthil dec-4