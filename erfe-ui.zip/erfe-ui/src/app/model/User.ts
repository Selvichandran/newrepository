export class User {
  active:string;
  deptCode:string;
  deptName:string;
  personFirstName:string;
  personId:string;
  personLastName:string;
  personMiddleName:string;
  personPhoneNum:string;
  userPin:string;

}

