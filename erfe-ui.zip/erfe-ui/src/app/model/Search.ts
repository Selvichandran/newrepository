export class Search{
    contact:string;
  rfeNo:string;
  psRequestNumber:string
    supplier:string
  projectTitle:string
  projectDescription:string
  departmentNumber:string
  wbs:string
  status:string
  orderBy:string
  sortBy:string
}
export class SearchTable{
    status:string;
    contact:string;
    rfe:string;
    psRequestNumber:string;
    supplier:string;
    projectTitle:string;
    projectDesc:string;
    costCenter:string;
    wbs:string;
}