export class AllDoc {
    status:String;
    requestor: String;
    psNumber: String;
    origDate : String;
    approver : String;
    rfeNumber: number;
}


