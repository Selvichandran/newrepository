export class GlobalUser {

    personId: string;
  actvStusInd: string;
  ccEmalAddr: string;
  celrPhonNbr: string;
  emalAddr: string;
  emplEmalAddr: string;
  faxNbr: string;
  pinStusInd: string;
  prsnName: string;
  prsnFrstName: string;
  prsnPrefFrstNm: string;
  prsnLastName: string;
  userPin: string;
  workPhonNbr: string;
  deptName: string;
  locDesc: string;
  mailLocDesc: string;
  prsnPosTitlDs: string;
  hibernateLazyInitializer :any;
  
  }