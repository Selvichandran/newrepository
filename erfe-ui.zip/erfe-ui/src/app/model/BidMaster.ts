export class BidMaster{
    bidId:number=0;
    bidName:string='';
}