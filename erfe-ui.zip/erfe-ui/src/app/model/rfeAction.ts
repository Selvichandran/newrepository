export class rfeAction{
    input :string;
    action:string;
    id:string;
}