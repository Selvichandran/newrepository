export class ApproverMasterDetail{
    approverId: number;
    ApproverName: string;
    personId: string;
    approvalAmount: number;
}