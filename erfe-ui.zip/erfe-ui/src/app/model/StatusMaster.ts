export class StatusMaster{
    statusId:number=0;
    statusName:String='';
}